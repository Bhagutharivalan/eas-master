# Ex1
# Write a function that asks the user to input a number in Celsius and converts to Fahrenheit
# Use Try/Except block to detect non integer