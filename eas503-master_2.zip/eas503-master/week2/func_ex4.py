# 4a ----------------
# Use the function from ex3 to print
# Happy birthday to you!!!
# Happy birthday to you!!!
# Happy birthday, dear John
# Happy birthday to you!!!
# Happy birthday to you!!!


# 4b ---- repeat 4a for Jane