##################################################################
# for_ex9.py
# Write a function that uses the output from the 
# coin_toss function and calculates the probability of H and T
# Input: number of simulation
# Output: probability of H and T