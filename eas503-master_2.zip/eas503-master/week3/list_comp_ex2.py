###############################################################
# list_comp_ex2.py
# Re-write the following code to use List Comprehension
# # Multiply each number by 10

# my_list = [1, 2, 3]
# new_list = []
# for ele in my_list:
#     tmp = ele * 10
#     new_list.append(tmp)
