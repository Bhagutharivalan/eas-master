# 7 ---------------------
# Write a function that calculates the distance between two points
# and returns the value
# calculate_distance(x1,y1,x2,y2)
