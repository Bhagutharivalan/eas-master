###############################################################
# list_comp_ex5.py
# Use list comprehension to get the Truthiness of each element in my_list

my_list = [0, '', []]
