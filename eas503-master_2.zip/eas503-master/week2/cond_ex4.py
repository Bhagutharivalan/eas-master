# Modify ex3 to add conditionals to print no real roots, double root, roots
