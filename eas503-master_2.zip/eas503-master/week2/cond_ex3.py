# 3 ---------------------
# Write a function to calculate the solution to a quadratic equation
# https://www.mathsisfun.com/algebra/quadratic-equation.html
# Prompt the user to the coefficients a, b, and c. 




