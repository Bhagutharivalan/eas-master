# while_ex1
# Write a program that takes integers from the user and returns the average
# Use a while loop and make an empty string the stop criteria.
