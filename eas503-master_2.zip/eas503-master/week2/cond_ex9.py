# 9 ------------------
# Write a program that only allows a user to log in if they are a superuser or if they are are teach and active