# 1 -------------------
# Using the print function print:
# ______________________________
# Happy birthday to you!!!
# Happy birthday to you!!!
# Happy birthday, dear John
# Happy birthday to you!
# Happy birthday to you!
# ______________________________

