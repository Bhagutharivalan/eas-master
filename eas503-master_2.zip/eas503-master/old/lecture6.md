# Lecture 6
- self, classmethod, staticmethod, class_variable, instance_variable
- lambda, map, filter, sorted, min, and max
- Error Handling
- Modules
- Regular Expression
