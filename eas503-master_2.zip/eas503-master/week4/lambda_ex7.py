

# lambda_ex7.py
# Create a dictionary where the key is year and value is 
# True/False if the year is a leap year



