###############################################################
# list_comp_ex6.py
# convert each element of my_list to str using list comprehension

my_list = range(6)