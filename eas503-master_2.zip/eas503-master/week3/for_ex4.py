##################################################################
# for_ex4.py
# Write a function that multiplies the elements of the list by two and returns them
