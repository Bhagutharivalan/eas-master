# Write a function coin_toss() to simulate
# a coin toss. Return Head or Tail