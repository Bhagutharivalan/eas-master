###############################################################
# while_ex3
# Write a program that takes test grades from the user and returns their average and the letter grade of the average
# Use a while loop and make negative number the stop criteria.
# A >=90
# B 80-89
# C 70-79
# D 60-69
# F 59 or less
