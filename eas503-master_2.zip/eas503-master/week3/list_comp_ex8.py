###############################################################
# list_comp_ex8.py
# use list comprehension to modify a list of numbers such that evens are left as is
# and the odds are raised to the three power


numbers = range(10)
