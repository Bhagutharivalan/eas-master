# 2 -------------------
# Using the print function print:
# ______________________________
# Happy birthday to you!!!
# Happy birthday to you!!!
# Happy birthday, dear Jane
# Happy birthday to you!
# Happy birthday to you!
# ______________________________

