# lambda_ex1.py
# Write a function that squares a number and returns the value.
# Write it again again using Lambda functions





