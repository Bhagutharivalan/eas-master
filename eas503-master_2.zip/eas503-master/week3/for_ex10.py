##################################################################
# for_ex10.py
# Write a function that simulates coin_toss_probablity for a given number of times and calculates the average of H and T
# Input: number of simulations
# Input: number of coin tosses
# Output: average probability
