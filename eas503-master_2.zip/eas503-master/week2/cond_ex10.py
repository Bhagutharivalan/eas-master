# 9 ------------------
# Prompt user for age and check if they are 18 or older