# 5 -------------------
# Write a function called print_happy_birthday_name that takes
# the name as an input 
# Happy birthday, dear <Name>

