# Ex2
# Write a function that prints from 1 to n squared using a while loop.
# It should stop the while loop if the iteration count is 50. 
