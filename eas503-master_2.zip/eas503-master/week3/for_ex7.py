##################################################################
# for_ex7.py
# Write a function that reads grades from an input file and calculates their average
# input: filename
# use: for_ex7_data1.txt
# use: for_ex7_data2.txt
# use: for_ex7_data3.txt
# use a list to read the values in to and then use sum and len to calclate average.
# Be careful about empty rows!
# Be careful about non-numbers!