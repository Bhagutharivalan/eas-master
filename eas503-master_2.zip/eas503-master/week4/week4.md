# Week 4


## Topics
- Review HW1
- HW2 fetch again
- List comprehension examples 6-9
- For loop example 11
- Review list comprehension
- Data Structures (dictionaries, sets)
- Function Scopes 
- Lambda, Filter, and Map, Generators

## Review List Comprehension
	- simple
	- With a single conditional
	- with if/else conditional
	- order matters?

## Dictionaries
	- Create a new variable that holds a dictionary
	- add a key-value pair to dictionary
	- Update the value associated with a key in a dictionary
	- Iterate over all the keys and/or values in a dictionary
	- Functions with dictionary as parameters
	- zip
	- json -- dump/load

## Function Scopes

## Lambda, Filter, and Map

### Lambda
lambda a function without a name;
- anonymous functions;
- one line only;
- single expression only
- stored in a variable
- When do you use it? Pass a function into another function as a parameter
- lambda variables (comma separated): expression
- lambda functions are used with other functions. Usually with map, filter, sort

### Filter


### Map