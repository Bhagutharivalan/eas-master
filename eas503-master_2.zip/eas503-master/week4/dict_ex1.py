##############################################################
# dict_ex1.py
# Load people.tsv into a dictionary. 
# Prompt user for filename
