###############################################################
# for_ex1.py
# Write a function that takes in a list of values and returns its sum