# lambda_ex8.py
# Sort x using value

x = (('efg', 1), ('abc', 3), ('hij', 2))


