###############################################################
# list_comp_ex9.py
# use list comprehension to remove vowels from a sentence

sentence = 'I rEAlly want to gO to work'
