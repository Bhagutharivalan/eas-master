# KEY_tsp.py

def solve_tsp_nn(startNode, costDict, nodesDF): 
    """
    This function computes a "nearest neighbor" solution to a TSP.
    
    Inputs
    ------
    startNode: Integer, indicating the node where the salesperson begins (and ends) the route
    
    costDict: VeRoViz time or distance dictionary.
    
    nodesDF: VeRoViz nodes dataframe
    
    Returns
    -------
    An ordered list of nodeIDs specifying a TSP route.
    """
    
    # Solve the TSP with a "nearest neighbor" heuristic
    nn_route = []

    # Start our route by visiting the startNode
    nn_route.append(startNode)

    # Initialize a list of unvisited nodes
    unvisitedNodes = list(nodesDF[nodesDF['id'] != startNode]['id'])

    # Let i represent our "current" location:
    i = startNode

    while len(unvisitedNodes) > 0:
        # Initialize minTime to a huge value
        minTime = float('inf')

        # Find the nearest unvisited node to our current node:
        for j in unvisitedNodes:
            if (costDict[i,j] < minTime):
                nextNode = j
                minTime = costDict[i,j]

        # Update our salesperson's location
        i = nextNode

        # Append nextNode to our route:
        nn_route.append(nextNode)

        # Remove nextNode from our list of unvisitedNodes:
        unvisitedNodes.remove(nextNode)

    nn_route.append(startNode)

    return nn_route   
    
    
def tsp_cost(route, costDict):
    cost = 0
    
    i = route[0]
    for j in route[1:]:
        cost += costDict[i,j]
        i = j
        
    cost += costDict[i, route[0]]
    
    return cost
    
    
def tsp_neighbor(route):
    # Generate a neighboring solution to curTour
    # Suppose route = [3, 2, 1, 4, 3].
    # We'll choose a subtour, and reverse the order in which the cities in this
    # subtour are visited. 

    # a) Find the indices marking the start (a) and end (b) of our subtour:
    a = random.randint(0,len(route)-3)
    b = random.randint(a+1,len(route)-2)

    # b) Start with an empty tour:
    tmpRoute = []

    # c) Add the cities in positions 0 thru a-1: 
    tmpRoute.extend(route[0:a])

    # d) Add the cities in positions a thru b, but in reverse order:
    subTour = route[a:b+1]
    subTour.reverse()
    tmpRoute.extend(subTour)

    # e) Add the cities in positions b thru the end of the tour
    #    (but ignore the last city, which is also the first city):
    tmpRoute.extend(route[b+1:len(route)-1])

    # f) Complete the tour by routing back to what is now the starting city:
    tmpRoute.append(tmpRoute[0])
    
    return (tmpRoute)
    

import math
import random
import time
# import matplotlib.pyplot as plt

def solveTSP_SA(nodesDF, costDict, timeLimit):
    # nodesDF -- nodes dataframe
    # costDict -- either time or distance
    # timeLimit -- time limit, in [seconds]
	
    import veroviz as vrv
    import os
	
    ORS_API_KEY = os.environ['ORSKEY']
	
    X = {}
    Z = {}
    T = {}
    
    # Initialize Parameters
    T[0]       = 100  # Initial temperature
    I          =  10  # Iterations per temp
    delta      = 0.1  # Cooling schedule temperature
    T['final'] =  11  # Minimum allowable temp
    cutoffTime =  20  # seconds

    
    # Start procedure    
    # Get an initial feasible solution
    # We'll just use the nearest neighbor, starting with the "first" node.
    startNode = min(nodesDF['id'])
    X[0] = solve_tsp_nn(startNode, costDict, nodesDF)
    Z[0] = tsp_cost(X[0], costDict)
    
    X['cur'] = list(X[0])
    Z['cur'] = Z[0]
    T['cur'] = T[0]

    X['best'] = list(X['cur'])
    Z['best'] = Z['cur']

    myStartTime = time.clock()
        
    keepGoing = True
    while (keepGoing):
        
        for count in range(1, I+1):
            # Generate a neighbor solution
            X['candidate'] = tsp_neighbor(X['cur'])
            
            # Get the "cost" of this solution
            Z['candidate'] = tsp_cost(X['candidate'], costDict)
            
            # Do we keep the candidate solution?
            if (Z['candidate'] < Z['cur']):
                X['cur'] = list(X['candidate'])
                Z['cur'] = Z['candidate']
                # Green Dot at x = dummy, y = Z['candidate']
            else:
                deltaC = Z['candidate'] - Z['cur']
                if (random.random() <= math.exp(-deltaC/T['cur'])):
                    X['cur'] = list(X['candidate'])
                    Z['cur'] = Z['candidate']
                    
            # Have we found a new incumbent?
            if (Z['cur'] < Z['best']):
                Z['best'] = Z['cur']
                X['best'] = list(X['cur'])
                
        # Check termination criteria
        T['cur'] = T['cur'] - delta
        runTime = time.clock() - myStartTime
        if ((T['cur'] < T['final']) or (runTime >= cutoffTime)):
            keepGoing = False
    
    
    assignmentsDF = vrv.createAssignmentsFromNodeSeq2D(
        nodeSeq          = X['best'],     
        nodes            = nodesDF,
        routeType        = 'fastest',
        dataProvider     = 'ORS-online',
        dataProviderArgs = {'APIkey' : ORS_API_KEY})    # You'll need to replace ORS_API_KEY with your actual key

    return assignmentsDF 
            