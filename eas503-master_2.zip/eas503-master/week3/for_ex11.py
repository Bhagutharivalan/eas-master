##################################################################
# for_ex11.py
# Write a function that reads a file in which each line has multiple student
# grades and calculates the student average grade
# Print average of each student on screen
# Use list comprehension to convert grades to int
# use: for_ex11_data.txt

