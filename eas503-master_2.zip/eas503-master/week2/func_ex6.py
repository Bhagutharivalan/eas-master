# 6 ------------------------
# combine the functions print_happy_birthday and print_happy_birthday_name('John')