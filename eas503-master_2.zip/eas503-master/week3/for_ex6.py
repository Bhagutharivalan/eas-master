##################################################################
# for_ex6.py
# Write a function to remove duplicate from a list
