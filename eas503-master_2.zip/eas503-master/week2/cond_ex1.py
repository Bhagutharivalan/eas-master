# 1 ---------------------
# Write a program to prompt the user for temperature in Celsius, convert 
# the temperature to Fahrenheit, and print temperature in Fahrenheit. 


