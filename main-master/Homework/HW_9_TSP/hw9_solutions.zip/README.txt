This folder contains several files:

1.  hw9_solutions.ipynb
	This is the "main" file to run if you wish to see the solutions.

2.  KEY_tsp.py
	This file contains all of the necessary functions, which you were to have written for your assignment.
	The Jupyter notebook imports this file.
	
3.  nodes.csv, travelDistancesMeters.csv, and travelTimesSeconds.csv
	These are datafile that were used for testing and evaluation.  
	These files were generated with VeRoViz, and exported as .csv files.
	
	