##################################################################
# for_ex8.py
# Write a function simulates a coin toss
# Input: number of simulation
# Output: a string that concatenates the results, ex. 'HHHTTTHTHTHT'
