# Ex1
# Write a function that prints from 1 to n using a for loop, it should skip every
# multiple of 5

def modify_


