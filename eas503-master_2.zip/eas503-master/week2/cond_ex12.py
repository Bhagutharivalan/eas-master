# 12 ---------------
# Prompt the user to enter a number and check if it is even or odd