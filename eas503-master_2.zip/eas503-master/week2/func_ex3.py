# 3 ---------------------
# Write a function to print:
# Happy birthday to you!!!
# Happy birthday to you!!!