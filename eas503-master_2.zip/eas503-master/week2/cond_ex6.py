# 6 ------------------
# Write a program to prompt the user for their user name. 
# If it is jdoe, print a log in allowed message; otherwise, print another message