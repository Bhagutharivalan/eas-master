# x = 1

# # if x:
# #     print('True!')


# x = 0

# if x:
#     print('True!')
# else:
#     print('False')


# string_list = ['line1', 'line2', '']

# for element in string_list:
#     if element:
#         print(element)
#     else:
#         print('Empty')


# my_list = []

# if my_list:
#     print(my_list)
# else:
#     print('List is empty')


x = ['',]

for value in x:
    value = float(value)
    print(value, type(value))
    # else:
    #     print('Empty')

