def my_func(n):
    if n > 10:
        print('n is greater than 10')

    return (1,2)

# x = my_func(100)
# print(x)


def my_func2(n):

    if n > 10:
        print(10)
    elif n < 5:
        print(5)


my_func2(4)
