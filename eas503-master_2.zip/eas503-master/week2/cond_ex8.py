# 8 -----------------------
# Write a program to prompt the user for name and check if it is john or jane