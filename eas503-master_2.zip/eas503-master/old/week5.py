x = list(range(5))

idx = 0
for ele in x:
    x[idx] = ele*ele
    idx += 1
