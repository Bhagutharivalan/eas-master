##################################################################
# for_ex5.py
# Write a pow() function that computes the power of each element in a list
