####################################################
# dict_ex3.py 
# Convert text message to numbers