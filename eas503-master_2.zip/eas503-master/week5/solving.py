def func1(x, y=5, z):
    print(x*y)


func1(12,13)
func1(12)