# lambda_ex5.py
# Capitalize the names in the students list 
# 1) using a list and loop
# 2) using list comprehension
# 3) using lambda and filter
