####################################################
# dict_ex4.py 
# Write a function that uses enumerate to print the index and value from range.
# Use vary the enumerate start index



