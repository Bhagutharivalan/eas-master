###############################################################
# list_comp_ex7.py
# use list comprehension to reduce a list of numbers to just even or odd


numbers = range(20)

even = [number for number in numbers if number % 2 == 0]



