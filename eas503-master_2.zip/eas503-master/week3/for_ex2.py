###############################################################
# for_ex2.py
# Write a function that takes in a list of values and returns its average
