# while_ex4
# Write a program that takes an integer and counts down to zero -- print the value
