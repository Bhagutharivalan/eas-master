###############################################################
# list_comp_ex3.py
# Upper case each letter in animal variable

# # Works with any type of sequence

animal = 'buffalo'