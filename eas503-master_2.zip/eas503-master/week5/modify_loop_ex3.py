# Ex3
# Write a function that reads numbers from a file and prints their average. 
# Skip empty lines