# lambda_ex2.py
# Write a lambda function for adding two numbers

addnum = lambda x,y: x + y

print(addnum(1,2))
