##################################################################
# for_ex3.py
# Write a function that takes in a list of values and returns its average
# Instead of using a for loop as in ex2, use sum() and len() to calculate the average
