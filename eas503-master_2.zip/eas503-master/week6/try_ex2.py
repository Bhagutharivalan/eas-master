# Ex2
# Write a function that prompts users to input numbers to calculate their average. Use the word STOP
# to stop input process. 
# Use try and except to discard non-number inputs. 