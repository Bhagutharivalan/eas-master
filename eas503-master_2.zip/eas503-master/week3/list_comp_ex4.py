###############################################################
# list_comp_ex4.py
# Title each name in the student list

students = ['john', 'jane', 'doe']
