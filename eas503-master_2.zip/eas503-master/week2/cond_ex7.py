# 7 ------------------
# Modify ex6 to only allow login if the user is active