####################################################
# dict_ex2.py 
# Write a function to convert month number to 
# month name. First use a list and then a dictionary
