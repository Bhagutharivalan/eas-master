# 2 ---------------------
# Modify exercise 1 to print a message when F > 90 and F < 32
