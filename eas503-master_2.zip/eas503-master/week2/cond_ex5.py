# 5 --------------------
# Write a program to prompt the user for three numbers and print the maximum value