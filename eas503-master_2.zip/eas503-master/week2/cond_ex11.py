# 11 --------------------
# Prompt the user for two numbers and see if they are equal
