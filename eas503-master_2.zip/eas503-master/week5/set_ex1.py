# Ex1
# Write a function that takes name of two gene files, 
# reads them, and returns which genes are:
# 1) In first file but not in second file
# 2) In second file but not in first file
